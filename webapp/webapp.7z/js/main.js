"use strict";

import Person from './model/person.js';

let persons = [];

let ana = new Person('Ana Smith', new Date('1998-12-15'));
let bob = new Person('Bob Jone', new Date('1945-11-16'));
let carlos = new Person('Carlos Slim Helu', new Date('1976-09-24'));

console.log("Hello");
for(let p in persons){
    console.log(persons[p]);
}